import React, { useState, useEffect } from "react";
import "./styles.css";

export default function App() {
  const [wins, setWins] = useState(0); // Conts the wins that user makes
  const [loses, setLoses] = useState(0); // Conts the loses that user makes
  const [userChoice, setUserChoice] = useState(); // Gets hold of the user choce
  const [result, setResult] = useState(""); // Gets hold of the result strings
  const [responseImage, setResponseImage] = useState(""); // Gets hold of the response image url
  const [gameOver, setGameOver] = useState(false); // It is used to check if the game is over - like boolean
  const choices = ["rock", "paper", "scissors"]; // Random choices that computer will choce from

  // When computer chose random index it will get the url from this imageMap object
  const imageMap = {
    rock: "https://freesvg.org/img/misc-pet-rock.png",
    paper: "https://freesvg.org/img/Stack_of_papers.png",
    scissors: "https://freesvg.org/img/greenscissors.png"
  };

  // Function that will be triggered if user makes choice by clicking over rock, paper or scissors
  const handleChoice = (choice) => {
    // Checks if the game is over. While the gameOver is False it will continue working
    if (!gameOver) {
      setUserChoice(choice);

      const randomIndex = Math.floor(Math.random() * choices.length);
      const randomComputerChoice = choices[randomIndex];

      setResponseImage(imageMap[randomComputerChoice]);

      // All game conditions that might happen while playing the game
      if (choice == randomComputerChoice) {
        setResult("Draw");
      } else if (
        (choice == "rock" && randomComputerChoice == "scissors") ||
        (choice == "scissors" && randomComputerChoice == "paper") ||
        (choice == "paper" && randomComputerChoice == "rock")
      ) {
        setWins(wins + 1);
        setResult("You won!");
      } else {
        setLoses(loses + 1);
        setResult("You lost!");
      }

      if (wins === 3 || loses === 3) {
        setGameOver(true);
      }

      setTimeout(() => {
        setUserChoice("");
        if (gameOver) {
          resetGame();
        }
      }, 1000);
    }
  };

  // Function that resets the game
  const resetGame = () => {
    setWins(0);
    setLoses(0);
    setResult("");
    setResponseImage("");
    setGameOver(false);
  };

  // Gives alert if user has 3 wins or 3 loses. The count of wins and loses will be checked only if gameOver is True
  useEffect(() => {
    if (gameOver) {
      if (wins === 3) {
        alert("You won!");
      } else if (loses === 3) {
        alert("You lost!");
      }
    }
  }, [gameOver, wins]);

  return (
    <div className="App">
      <h1>Rock, Paper and Scissors Game</h1>
      <h2 className="points">Wins: {wins}</h2>
      <h2 className="loses">Loses: {loses}</h2>
      <h2>Choose one:</h2>
      <div className="image-container">
        <img
          src="https://freesvg.org/img/misc-pet-rock.png"
          alt="img_rock"
          className="image"
          id="rock-button"
          onClick={() => handleChoice("rock")}
        />
        <img
          src="https://freesvg.org/img/Stack_of_papers.png"
          alt="img_paper"
          className="image"
          id="paper-button"
          onClick={() => handleChoice("paper")}
        />
        <img
          src="https://freesvg.org/img/greenscissors.png"
          alt="img_scissors"
          className="image"
          id="scissors-button"
          onClick={() => handleChoice("scissors")}
        />
      </div>
      <h2>Vs</h2>
      <div className="result-container">
        {responseImage === "" || result === "" ? (
          <h1>Computer is waiting for you to make a choice...</h1>
        ) : (
          <>
            {result && <h2 style={{ marginBottom: "50px" }}>{result}</h2>}
            <img
              src={responseImage}
              alt="response"
              className="response-image"
            />
          </>
        )}
      </div>

      {gameOver && (
        <button onClick={resetGame} className="play-again-button">
          Play Again
        </button>
      )}
    </div>
  );
}
